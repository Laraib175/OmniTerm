import code

def run_python_interpreter():
    print("🧠 OmniTerm Inline Python Interpreter")
    print("Type your Python code below. Type 'exit()' to quit.\n")
    
    # Start an interactive interpreter
    console = code.InteractiveConsole()
    console.interact()

if __name__ == "__main__":
    run_python_interpreter()
