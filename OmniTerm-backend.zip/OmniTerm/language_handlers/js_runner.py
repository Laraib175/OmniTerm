import subprocess
import tempfile
import os

def run_js_code(code: str):
    import subprocess
    try:
        # Option 1: pipe code to Node directly (no temp file)
        proc = subprocess.run(
            ["node", "-e", code],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        return {"stdout": proc.stdout, "stderr": proc.stderr, "returncode": proc.returncode}

    except Exception as e:
        return {"stdout": "", "stderr": str(e), "returncode": -1}
