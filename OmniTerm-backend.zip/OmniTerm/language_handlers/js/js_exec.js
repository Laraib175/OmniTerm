#!/usr/bin/env node
'use strict';

// Read code from stdin
let code = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => code += chunk);
process.stdin.on('end', async () => {
  try {
    // Wrap user code in an async IIFE so 'await' works
    const wrapped = `(async () => { ${code} })()`;
    // Evaluate the wrapped code (returns a Promise for async IIFE)
    await eval(wrapped);
    // exit with 0 (success)
    process.exit(0);
  } catch (err) {
    // Print stack or message to stderr and exit non-zero
    console.error(err && err.stack ? err.stack : String(err));
    process.exit(1);
  }
});

// Ensure we start reading
process.stdin.resume();
