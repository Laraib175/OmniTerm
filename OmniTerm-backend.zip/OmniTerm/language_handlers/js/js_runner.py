import subprocess
import tempfile
import os

def run_js_code(code):
    """Runs a JavaScript snippet using Node.js"""
    try:
        # Create a temporary JS file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".js", mode="w") as temp_js:
            temp_js.write(code)
            temp_js_path = temp_js.name

        # Execute JS using Node
        result = subprocess.run(["node", temp_js_path], capture_output=True, text=True)

        # Clean up
        os.remove(temp_js_path)

        # Display output or errors
        if result.stdout:
            print("Output:\n", result.stdout)
        if result.stderr:
            print("Error:\n", result.stderr)

    except Exception as e:
        print(f"⚠️ Error running JavaScript code: {e}")
