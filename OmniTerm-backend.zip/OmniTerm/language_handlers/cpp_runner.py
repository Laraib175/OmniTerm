CPP_TEMP_FILE = "/tmp/omniterm_temp.cpp"
CPP_EXE_FILE = "/tmp/omniterm_temp"
import subprocess
import tempfile
import os

def run_cpp_code(code: str):
    import subprocess, os
    try:
        with open(CPP_TEMP_FILE, "w") as f:
            f.write(code)

        compile_proc = subprocess.run(
            ["g++", CPP_TEMP_FILE, "-o", CPP_EXE_FILE],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        if compile_proc.returncode != 0:
            return {
                "stdout": "",
                "stderr": compile_proc.stderr,
                "returncode": compile_proc.returncode
            }

        run_proc = subprocess.run(
            [CPP_EXE_FILE],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )

        return {
            "stdout": run_proc.stdout,
            "stderr": run_proc.stderr,
            "returncode": run_proc.returncode
        }

    except Exception as e:
        return {"stdout": "", "stderr": str(e), "returncode": -1}

    finally:
        try: os.remove(CPP_TEMP_FILE)
        except: pass
        try: os.remove(CPP_EXE_FILE)
        except: pass
