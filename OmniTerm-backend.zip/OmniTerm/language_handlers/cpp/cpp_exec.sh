#!/usr/bin/env bash
# C++ Inline Executor for OmniTerm
# Reads code from stdin, compiles, executes, and prints output/errors.

set -e  # stop on first error
TMPDIR=$(mktemp -d)
SRCFILE="$TMPDIR/temp.cpp"
BINFILE="$TMPDIR/temp.out"

# Read C++ code from stdin and save to a temp file
cat > "$SRCFILE"

# Try to compile
if ! g++ -std=c++17 "$SRCFILE" -o "$BINFILE" 2> "$TMPDIR/compile_error.txt"; then
    echo "[Compilation Failed]" >&2
    cat "$TMPDIR/compile_error.txt" >&2
    rm -rf "$TMPDIR"
    exit 1
fi

# Run the compiled binary and capture output
if ! "$BINFILE"; then
    echo "[Runtime Error]" >&2
    rm -rf "$TMPDIR"
    exit 1
fi

# Clean up temporary files
rm -rf "$TMPDIR"
