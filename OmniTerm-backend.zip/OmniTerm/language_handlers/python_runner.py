# language_handlers/python_runner.py
import io
import contextlib
import traceback
python_globals = {}
def run_python_code(code: str):
    import io, contextlib, traceback
    output_buffer = io.StringIO()
    err_buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(output_buffer), contextlib.redirect_stderr(err_buffer):
            exec(code, python_globals)  # <-- use persistent globals
        return {
            "stdout": output_buffer.getvalue(),
            "stderr": err_buffer.getvalue(),
            "returncode": 0
        }
    except Exception:
        tb = traceback.format_exc()
        return {
            "stdout": "",
            "stderr": tb,
            "returncode": 1
        }
