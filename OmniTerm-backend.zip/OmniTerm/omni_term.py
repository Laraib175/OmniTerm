import time
import readline
import os
import atexit
import threading
from language_handlers.python_runner import run_python_code
from language_handlers.cpp_runner import run_cpp_code
from language_handlers.js_runner import run_js_code

# History setup
history_file = os.path.expanduser("~/.omniterm_history")
if os.path.exists(history_file):
    readline.read_history_file(history_file)
atexit.register(lambda: readline.write_history_file(history_file))
readline.set_history_length(1000)

# ANSI color codes
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"

print("🔷 OmniTerm – Multi-Language Command Terminal")
print("Commands:")
print("  lang <py|cpp|js>        -> set default language for code entry")
print("  mode autodetect on|off  -> toggle simple auto-detection")
print("  py / cpp / js           -> enter multiline for that language immediately")
print("  bg                      -> run code in background thread")
print("  run                     -> run buffered code in current language (optional)")
print("  exit                    -> quit\n")

# Default settings
current_lang = "py"
auto_detect = False
last_buffer = ""  # store last entered buffer
bg_threads = []   # track background threads

def read_multiline(end_word="done"):
    print(f"(Enter code; type '{end_word}' on a new line to finish.)")
    lines = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip().lower() == end_word:
            break
        lines.append(line)
    return "\n".join(lines)

def detect_language_snippet(code: str):
    """Simple heuristic: returns 'cpp', 'js', or 'py'"""
    s = code.strip()
    if not s:
        return "py"
    if "#include" in s or "std::" in s or "int main(" in s:
        return "cpp"
    if "console.log" in s or "let " in s or "const " in s or "function " in s:
        return "js"
    return "py"

def run_code(lang, code):
    """Run code with execution time and colored output"""
    start = time.time()
    if lang == "py":
        result = run_python_code(code)
    elif lang == "cpp":
        result = run_cpp_code(code)
    else:
        result = run_js_code(code)
    end = time.time()

    out = result.get("stdout", "")
    err = result.get("stderr", "")
    returncode = result.get("returncode", 1)

    # Output
    if out.strip():
        print("Output:\n" + out, end="")
    if err.strip():
        print(f"{RED}Error:\n  " + err.replace("\n", "\n  ") + f"{RESET}", end="")

    # Execution status
    if returncode == 0:
        print(f"{GREEN}[Execution succeeded]{RESET}")
    else:
        print(f"{RED}[Execution failed]{RESET}")

    # Execution time
    print(f"[Execution time: {end-start:.3f}s]")

def run_code_threaded(lang, code):
    """Run code in a separate thread"""
    t = threading.Thread(target=run_code, args=(lang, code))
    t.start()
    bg_threads.append(t)
    print(f"{YELLOW}[Background thread started]{RESET}")

# --- Main loop ---
while True:
    cmd = input(f"OmniTerm ({current_lang})> ").strip()
    if not cmd:
        continue

    # Exit
    if cmd.lower() in ("exit", "quit"):
        print("Goodbye 👋")
        # Wait for all background threads to finish
        if bg_threads:
            print("Waiting for background tasks to finish...")
            for t in bg_threads:
                t.join()
        break

    # Set default language
    if cmd.startswith("lang "):
        parts = cmd.split()
        if len(parts) >= 2 and parts[1] in ("py", "cpp", "js"):
            current_lang = parts[1]
            print(f"Default language set to: {current_lang}")
        else:
            print("Usage: lang <py|cpp|js>")
        continue

    # Toggle auto-detect mode
    if cmd.startswith("mode "):
        parts = cmd.split()
        if len(parts) >= 2 and parts[1] == "autodetect":
            if len(parts) == 3 and parts[2] in ("on", "off"):
                auto_detect = (parts[2] == "on")
                print(f"Auto-detect set to: {auto_detect}")
            else:
                print("Usage: mode autodetect on|off")
        else:
            print("Unknown mode command. Supported: mode autodetect on|off")
        continue

    # Run code in background
    if cmd == "bg":
        code = read_multiline("done")
        lang = current_lang
        if auto_detect:
            detected = detect_language_snippet(code)
            print(f"{YELLOW}[auto-detect] detected as: {detected}{RESET}")
            lang = detected
        run_code_threaded(lang, code)
        continue

    # Immediate multiline entry for a specific language
    if cmd in ("py", "cpp", "js"):
        lang = cmd
        code = read_multiline("done")
        last_buffer = code
        if auto_detect:
            detected = detect_language_snippet(code)
            print(f"{YELLOW}[auto-detect] detected as: {detected}{RESET}")
            lang = detected
        run_code(lang, code)
        continue

    # Run stored buffer
    if cmd == "run":
        if not last_buffer.strip():
            print("No stored buffer to run. Use py/cpp/js or type code first.")
            continue
        lang = current_lang
        code = last_buffer
        if auto_detect:
            detected = detect_language_snippet(code)
            print(f"{YELLOW}[auto-detect] detected as: {detected}{RESET}")
            lang = detected
        run_code(lang, code)
        continue

    # Direct code entry (treated as first line of multiline)
    print(f"Entering multiline mode for language '{current_lang}'.")
    print("You already entered the first line; continue entering lines and finish with 'done'.")
    lines = [cmd]
    while True:
        try:
            line = input()
        except EOFError:
            break
        if line.strip().lower() == "done":
            break
        lines.append(line)
    code = "\n".join(lines)
    last_buffer = code

    lang = current_lang
    if auto_detect:
        detected = detect_language_snippet(code)
        print(f"{YELLOW}[auto-detect] detected as: {detected}{RESET}")
        lang = detected

    run_code(lang, code)

