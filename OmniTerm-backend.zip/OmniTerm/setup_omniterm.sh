#!/bin/bash
# OmniTerm Setup Script
# Run this once to add a convenient "omniterm" alias to ~/.bashrc (or ~/.profile)

ALIAS_LINE="alias omniterm='python3 ~/OmniTerm/omni_term.py'"

# Add alias only if it doesn't already exist
if ! grep -Fxq "$ALIAS_LINE" ~/.bashrc 2>/dev/null; then
    echo "" >> ~/.bashrc
    echo "# OmniTerm alias (added by setup_omniterm.sh)" >> ~/.bashrc
    echo "$ALIAS_LINE" >> ~/.bashrc
    echo "Added alias to ~/.bashrc"
else
    echo "Alias already exists in ~/.bashrc"
fi

# Try to apply immediately for current shell
if [ -n "$BASH_VERSION" ]; then
    source ~/.bashrc
    echo "Sourced ~/.bashrc in current shell"
fi

echo "✅ OmniTerm alias available. You can now run: omniterm"
