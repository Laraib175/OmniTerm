from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

# Add language_handlers to path
sys.path.append(os.path.dirname(__file__))

from language_handlers.python_runner import run_python_code
from language_handlers.cpp_runner import run_cpp_code
from language_handlers.js_runner import run_js_code

app = Flask(__name__)
CORS(app)  # Enable CORS for Next.js frontend

def detect_language(code):
    """Auto-detect language from code"""
    code = code.strip()
    
    # C++ detection
    if "#include" in code or "std::" in code or "int main" in code:
        return "cpp"
    
    # JavaScript detection
    if "console.log" in code or "let " in code or "const " in code or "function " in code:
        return "js"
    
    # Python detection (default)
    return "py"

@app.route('/api/run', methods=['POST'])
def run_code():
    try:
        data = request.json
        code = data.get('code', '')
        language = data.get('language', 'py')
        auto_detect = data.get('autoDetect', False)
        
        # Auto-detect language if enabled
        if auto_detect:
            detected = detect_language(code)
            language = detected
        
        # Execute code based on language
        if language == 'py':
            stdout, stderr = run_python_code(code)
            returncode = 0 if not stderr else 1
        elif language == 'cpp':
            stdout, stderr = run_cpp_code(code)
            returncode = 0 if not stderr else 1
        elif language == 'js':
            stdout, stderr = run_js_code(code)
            returncode = 0 if not stderr else 1
        else:
            return jsonify({
                'stdout': '',
                'stderr': f'Unsupported language: {language}',
                'returncode': 1,
                'detectedLanguage': language
            })
        
        return jsonify({
            'stdout': stdout,
            'stderr': stderr,
            'returncode': returncode,
            'detectedLanguage': language
        })
    
    except Exception as e:
        return jsonify({
            'stdout': '',
            'stderr': str(e),
            'returncode': -1
        }), 500

@app.route('/api/ping', methods=['GET'])
def ping():
    return jsonify({'status': 'ok', 'message': 'OmniTerm API is running'})

if __name__ == '__main__':
    print("🚀 OmniTerm API Server starting...")
    print("📡 Listening on http://localhost:8000")
    app.run(host='0.0.0.0', port=8000, debug=True)
