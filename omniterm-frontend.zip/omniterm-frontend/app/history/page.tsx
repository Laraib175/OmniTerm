'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/UI/Navbar';
import { 
  getHistory, 
  clearHistory, 
  exportHistory, 
  formatTimestamp, 
  getLanguageEmoji, 
  type HistoryItem 
} from '@/utils/api';
import { 
  Clock, 
  Code2, 
  Trash2, 
  Copy, 
  CheckCircle, 
  XCircle, 
  Download, 
  Filter,
  Search,
  Calendar
} from 'lucide-react';

export default function HistoryPage() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<HistoryItem | null>(null);
  const [filter, setFilter] = useState<'all' | 'success' | 'error'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = () => {
    setHistory(getHistory());
  };

  const handleClearHistory = () => {
    if (confirm('⚠️ Are you sure you want to clear all execution history? This cannot be undone.')) {
      clearHistory();
      setHistory([]);
      setSelectedItem(null);
    }
  };

  const handleExport = () => {
    exportHistory();
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
  };

  const filteredHistory = history.filter((item) => {
    const matchesFilter = filter === 'all' || item.status === filter;
    const matchesSearch = item.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.language.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getLanguageColor = (lang: string) => {
    const colors: Record<string, string> = {
      py: 'from-blue-500 to-cyan-500',
      cpp: 'from-purple-500 to-pink-500',
      js: 'from-yellow-500 to-orange-500',
    };
    return colors[lang] || 'from-gray-500 to-gray-700';
  };

  return (
    <div className="min-h-screen">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
        
        {/* Header */}
        <div className="card-3d glass-hacker rounded-2xl p-8 border-2 border-matrix-green/30 shadow-2xl shadow-matrix-green/10">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold text-matrix-green font-mono flex items-center gap-3 glitch" data-text="EXECUTION_HISTORY">
                <Clock className="w-10 h-10" />
                EXECUTION_HISTORY
              </h1>
              <p className="mt-2 text-neon-cyan font-mono text-sm">
                {'>'} {history.length} total executions recorded
              </p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={handleExport}
                disabled={history.length === 0}
                className="btn-hacker px-6 py-3 rounded-xl font-mono font-semibold transition-all disabled:opacity-30 flex items-center gap-2 text-neon-cyan hover:text-matrix-green"
              >
                <Download className="w-5 h-5" />
                EXPORT
              </button>
              <button
                onClick={handleClearHistory}
                disabled={history.length === 0}
                className="btn-hacker px-6 py-3 rounded-xl font-mono font-semibold transition-all disabled:opacity-30 flex items-center gap-2 text-red-500 hover:text-red-400 border-red-500/30 hover:border-red-500"
              >
                <Trash2 className="w-5 h-5" />
                CLEAR_ALL
              </button>
            </div>
          </div>

          {/* Filters and Search */}
          <div className="flex flex-col md:flex-row gap-4">
            {/* Filter Buttons */}
            <div className="flex gap-2">
              {[
                { value: 'all', label: 'ALL', icon: Filter },
                { value: 'success', label: 'SUCCESS', icon: CheckCircle },
                { value: 'error', label: 'ERROR', icon: XCircle }
              ].map((f) => {
                const Icon = f.icon;
                return (
                  <button
                    key={f.value}
                    onClick={() => setFilter(f.value as any)}
                    className={`px-4 py-2 rounded-lg font-mono font-semibold transition-all flex items-center gap-2 ${
                      filter === f.value
                        ? 'bg-matrix-green/20 text-matrix-green border border-matrix-green'
                        : 'text-neon-cyan border border-neon-cyan/30 hover:border-matrix-green/50 hover:text-matrix-green'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {f.label}
                  </button>
                );
              })}
            </div>

            {/* Search Bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-neon-cyan/50" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search code or language..."
                className="w-full pl-11 pr-4 py-2 bg-black/50 border border-matrix-green/30 rounded-lg text-matrix-green placeholder-neon-cyan/30 font-mono text-sm focus:outline-none focus:border-matrix-green"
              />
            </div>
          </div>
        </div>

        {/* History Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* History List */}
          <div className="space-y-4">
            {filteredHistory.length === 0 ? (
              <div className="card-3d glass-hacker rounded-2xl p-12 text-center border-2 border-matrix-green/30">
                <Clock className="w-16 h-16 mx-auto mb-4 text-neon-cyan/30" />
                <p className="text-neon-cyan font-mono">
                  {history.length === 0 
                    ? '{'>'} No execution history found. Start coding to see your history!'
                    : '{'>'} No results match your filters'}
                </p>
              </div>
            ) : (
              filteredHistory.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className={`card-3d glass-hacker rounded-xl p-5 cursor-pointer transition-all border-2 hover:scale-105 ${
                    selectedItem?.id === item.id 
                      ? 'border-matrix-green shadow-lg shadow-matrix-green/50' 
                      : 'border-matrix-green/20 hover:border-matrix-green/50'
                  }`}
                >
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className={`px-3 py-1 rounded-lg text-sm font-bold text-white font-mono bg-gradient-to-r ${getLanguageColor(item.language)}`}>
                        {getLanguageEmoji(item.language)} {item.language.toUpperCase()}
                      </span>
                      {item.status === 'success' ? (
                        <CheckCircle className="w-5 h-5 text-matrix-green" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        copyCode(item.code);
                      }}
                      className="p-2 hover:bg-matrix-green/10 rounded-lg transition-all text-neon-cyan hover:text-matrix-green"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Code Preview */}
                  <div className="text-sm text-matrix-green font-mono bg-black/50 p-3 rounded-lg mb-3 line-clamp-2 border border-matrix-green/20">
                    {item.code}
                  </div>

                  {/* Footer */}
                  <div className="flex items-center justify-between text-xs text-neon-cyan/70 font-mono">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3 h-3" />
                      {formatTimestamp(item.timestamp)}
                    </div>
                    {item.executionTime && (
                      <span>{item.executionTime}ms</span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Detail View */}
          <div className="sticky top-24">
            {selectedItem ? (
              <div className="card-3d glass-hacker rounded-2xl p-6 border-2 border-matrix-green/30 shadow-2xl shadow-matrix-green/10">
                {/* Header */}
                <div className="flex items-center justify-between mb-6 pb-4 border-b border-matrix-green/20">
                  <h3 className="text-xl font-bold text-matrix-green font-mono flex items-center gap-2">
                    <Code2 className="w-6 h-6" />
                    EXECUTION_DETAILS
                  </h3>
                  <button
                    onClick={() => copyCode(selectedItem.code)}
                    className="btn-hacker px-4 py-2 rounded-lg font-mono font-semibold text-sm text-neon-cyan hover:text-matrix-green flex items-center gap-2"
                  >
                    <Copy className="w-4 h-4" />
                    COPY
                  </button>
                </div>

                {/* Code Section */}
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-semibold text-neon-cyan font-mono mb-2 block">
                      {'>'} CODE:
                    </label>
                    <pre className="p-4 rounded-lg font-mono text-sm bg-black border border-matrix-green/30 text-matrix-green overflow-x-auto max-h-64 overflow-y-auto scanlines">
                      {selectedItem.code}
                    </pre>
                  </div>

                  {/* Output Section */}
                  <div>
                    <label className="text-sm font-semibold text-neon-cyan font-mono mb-2 block">
                      {'>'} OUTPUT:
                    </label>
                    <pre className={`p-4 rounded-lg font-mono text-sm bg-black border border-matrix-green/30 overflow-x-auto max-h-64 overflow-y-auto scanlines ${
                      selectedItem.status === 'success' ? 'text-matrix-green' : 'text-red-400'
                    }`}>
                      {selectedItem.output}
                    </pre>
                  </div>

                  {/* Metadata */}
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-matrix-green/20">
                    <div>
                      <span className="text-xs text-neon-cyan/70 font-mono block mb-1">STATUS:</span>
                      <div className="flex items-center gap-2">
                        {selectedItem.status === 'success' ? (
                          <>
                            <CheckCircle className="w-5 h-5 text-matrix-green" />
                            <span className="text-matrix-green font-mono font-semibold">SUCCESS</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-5 h-5 text-red-500" />
                            <span className="text-red-500 font-mono font-semibold">ERROR</span>
                          </>
                        )}
                      </div>
                    </div>
                    <div>
                      <span className="text-xs text-neon-cyan/70 font-mono block mb-1">LANGUAGE:</span>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{getLanguageEmoji(selectedItem.language)}</span>
                        <span className="text-matrix-green font-mono font-semibold">{selectedItem.language.toUpperCase()}</span>
                      </div>
                    </div>
                    <div>
                      <span className="text-xs text-neon-cyan/70 font-mono block mb-1">TIMESTAMP:</span>
                      <span className="text-neon-cyan font-mono text-sm">
                        {new Date(selectedItem.timestamp).toLocaleString()}
                      </span>
                    </div>
                    {selectedItem.executionTime && (
                      <div>
                        <span className="text-xs text-neon-cyan/70 font-mono block mb-1">EXEC_TIME:</span>
                        <span className="text-neon-cyan font-mono text-sm">
                          {selectedItem.executionTime}ms
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="card-3d glass-hacker rounded-2xl p-12 text-center border-2 border-matrix-green/30">
                <Code2 className="w-16 h-16 mx-auto mb-4 text-neon-cyan/30" />
                <p className="text-neon-cyan font-mono">
                  {'>'} Select an execution to view details
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}