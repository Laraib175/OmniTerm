'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function TerminalRedirect() {
  const router = useRouter();

  useEffect(() => {
    // Redirect to main page
    router.push('/');
  }, [router]);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900">
      <div className="text-white text-xl">Redirecting to terminal...</div>
    </div>
  );
}
