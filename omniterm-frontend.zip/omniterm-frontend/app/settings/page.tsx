'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/UI/Navbar';
import { getSettings, saveSettings } from '@/utils/api';
import { 
  Settings as SettingsIcon, 
  Save, 
  RotateCcw, 
  Palette, 
  Code2, 
  Bell,
  Volume2,
  Zap,
  Shield
} from 'lucide-react';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    darkMode: true,
    autoDetect: true,
    fontSize: 14,
    theme: 'hacker',
    notifications: true,
    autoSave: false,
    soundEffects: false,
  });

  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    const loadedSettings = getSettings();
    setSettings(loadedSettings);
  }, []);

  const handleSave = () => {
    saveSettings(settings);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleReset = () => {
    if (confirm('⚠️ Reset all settings to default values?')) {
      const defaultSettings = {
        darkMode: true,
        autoDetect: true,
        fontSize: 14,
        theme: 'hacker',
        notifications: true,
        autoSave: false,
        soundEffects: false,
      };
      setSettings(defaultSettings);
      saveSettings(defaultSettings);
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 3000);
    }
  };

  const updateSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen pb-12">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 py-8 space-y-6">
        
        {/* Header */}
        <div className="card-3d glass-hacker rounded-2xl p-8 border-2 border-matrix-green/30 shadow-2xl shadow-matrix-green/10">
          <h1 className="text-4xl font-bold text-matrix-green font-mono flex items-center gap-3 glitch mb-3" data-text="SYSTEM_SETTINGS">
            <SettingsIcon className="w-10 h-10" />
            SYSTEM_SETTINGS
          </h1>
          <p className="text-neon-cyan font-mono text-sm">
            {'>'} Configure your OmniTerm experience
          </p>
        </div>

        {/* Editor Settings */}
        <div className="card-3d glass-hacker rounded-2xl p-8 border-2 border-matrix-green/30 shadow-xl shadow-matrix-green/10">
          <h2 className="text-2xl font-bold text-matrix-green font-mono flex items-center gap-3 mb-6">
            <Code2 className="w-6 h-6" />
            EDITOR_CONFIG
          </h2>

          <div className="space-y-6">
            {/* Auto Detect */}
            <div className="flex items-center justify-between p-4 bg-black/30 rounded-lg border border-matrix-green/20">
              <div>
                <label className="font-semibold text-matrix-green font-mono">AUTO_DETECT_LANGUAGE</label>
                <p className="text-sm text-neon-cyan/70 font-mono mt-1">
                  Automatically detect programming language from code
                </p>
              </div>
              <button
                onClick={() => updateSetting('autoDetect', !settings.autoDetect)}
                className={`relative w-16 h-8 rounded-full transition-all ${
                  settings.autoDetect ? 'bg-matrix-green' : 'bg-gray-600'
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform shadow-lg ${
                    settings.autoDetect ? 'translate-x-8' : ''
                  }`}
                />
              </button>
            </div>

            {/* Font Size */}
            <div className="p-4 bg-black/30 rounded-lg border border-matrix-green/20">
              <label className="font-semibold text-matrix-green font-mono block mb-4">
                FONT_SIZE: {settings.fontSize}px
              </label>
              <input
                type="range"
                min="10"
                max="24"
                value={settings.fontSize}
                onChange={(e) => updateSetting('fontSize', Number(e.target.value))}
                className="w-full h-2 bg-black rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #00ff41 0%, #00ff41 ${((settings.fontSize - 10) / 14) * 100}%, #1a1f3a ${((settings.fontSize - 10) / 14) * 100}%, #1a1f3a 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-neon-cyan/50 font-mono mt-2">
                <span>10px</span>
                <span>24px</span>
              </div>
            </div>

            {/* Theme Selection */}
            <div className="p-4 bg-black/30 rounded-lg border border-matrix-green/20">
              <label className="font-semibold text-matrix-green font-mono block mb-4">
                TERMINAL_THEME
              </label>
              <div className="grid grid-cols-3 gap-3">
                {['hacker', 'matrix', 'cyberpunk'].map((theme) => (
                  <button
                    key={theme}
                    onClick={() => updateSetting('theme', theme)}
                    className={`p-4 rounded-lg font-mono font-semibold transition-all ${
                      settings.theme === theme
                        ? 'bg-matrix-green/20 text-matrix-green border-2 border-matrix-green'
                        : 'text-neon-cyan border-2 border-neon-cyan/30 hover:border-matrix-green/50'
                    }`}
                  >
                    {theme.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {/* Auto Save */}
            <div className="flex items-center justify-between p-4 bg-black/30 rounded-lg border border-matrix-green/20">
              <div>
                <label className="font-semibold text-matrix-green font-mono">AUTO_SAVE</label>
                <p className="text-sm text-neon-cyan/70 font-mono mt-1">
                  Automatically save code as you type
                </p>
              </div>
              <button
                onClick={() => updateSetting('autoSave', !settings.autoSave)}
                className={`relative w-16 h-8 rounded-full transition-all ${
                  settings.autoSave ? 'bg-matrix-green' : 'bg-gray-600'
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform shadow-lg ${
                    settings.autoSave ? 'translate-x-8' : ''
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* System Settings */}
        <div className="card-3d glass-hacker rounded-2xl p-8 border-2 border-matrix-green/30 shadow-xl shadow-matrix-green/10">
          <h2 className="text-2xl font-bold text-matrix-green font-mono flex items-center gap-3 mb-6">
            <Shield className="w-6 h-6" />
            SYSTEM_CONFIG
          </h2>

          <div className="space-y-6">
            {/* Notifications */}
            <div className="flex items-center justify-between p-4 bg-black/30 rounded-lg border border-matrix-green/20">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-matrix-green" />
                <div>
                  <label className="font-semibold text-matrix-green font-mono">NOTIFICATIONS</label>
                  <p className="text-sm text-neon-cyan/70 font-mono mt-1">
                    Get notified about execution results
                  </p>
                </div>
              </div>
              <button
                onClick={() => updateSetting('notifications', !settings.notifications)}
                className={`relative w-16 h-8 rounded-full transition-all ${
                  settings.notifications ? 'bg-matrix-green' : 'bg-gray-600'
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform shadow-lg ${
                    settings.notifications ? 'translate-x-8' : ''
                  }`}
                />
              </button>
            </div>

            {/* Sound Effects */}
            <div className="flex items-center justify-between p-4 bg-black/30 rounded-lg border border-matrix-green/20">
              <div className="flex items-center gap-3">
                <Volume2 className="w-5 h-5 text-matrix-green" />
                <div>
                  <label className="font-semibold text-matrix-green font-mono">SOUND_EFFECTS</label>
                  <p className="text-sm text-neon-cyan/70 font-mono mt-1">
                    Play sound effects for actions
                  </p>
                </div>
              </div>
              <button
                onClick={() => updateSetting('soundEffects', !settings.soundEffects)}
                className={`relative w-16 h-8 rounded-full transition-all ${
                  settings.soundEffects ? 'bg-matrix-green' : 'bg-gray-600'
                }`}
              >
                <div
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-transform shadow-lg ${
                    settings.soundEffects ? 'translate-x-8' : ''
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4">
          <button
            onClick={handleSave}
            className="flex-1 btn-hacker py-6 rounded-xl font-bold text-lg font-mono transition-all flex items-center justify-center gap-3 bg-matrix-green/20 hover:bg-matrix-green/30 text-matrix-green border-2 border-matrix-green shadow-lg shadow-matrix-green/30"
          >
            <Save className="w-6 h-6" />
            {isSaved ? 'SAVED!' : 'SAVE_SETTINGS'}
          </button>
          <button
            onClick={handleReset}
            className="flex-1 btn-hacker py-6 rounded-xl font-bold text-lg font-mono transition-all flex items-center justify-center gap-3 bg-red-500/20 hover:bg-red-500/30 text-red-500 border-2 border-red-500 shadow-lg shadow-red-500/30"
          >
            <RotateCcw className="w-6 h-6" />
            RESET_DEFAULTS
          </button>
        </div>

        {/* Info Box */}
        <div className="glass-hacker rounded-xl p-6 border border-neon-cyan/30">
          <div className="flex items-start gap-3">
            <Zap className="w-6 h-6 text-matrix-green flex-shrink-0 mt-1" />
            <div>
              <p className="text-neon-cyan font-mono text-sm">
                <span className="text-matrix-green font-bold">{'>'} PRO_TIP:</span> Press{' '}
                <kbd className="px-2 py-1 bg-black rounded border border-matrix-green text-matrix-green">
                  Ctrl
                </kbd>
                {' + '}
                <kbd className="px-2 py-1 bg-black rounded border border-matrix-green text-matrix-green">
                  Enter
                </kbd>
                {' '}in the editor to quickly execute your code!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
