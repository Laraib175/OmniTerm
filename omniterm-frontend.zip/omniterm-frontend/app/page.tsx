'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/UI/Navbar';
import CodeEditor from '@/components/UI/CodeEditor';
import TerminalWindow from '@/components/UI/TerminalWindow';
import { Play, Sparkles, Zap, Code2 } from 'lucide-react';
import { runCode, saveToHistory, getSettings, saveSettings, saveLastCode, getLastCode } from '@/utils/api';
import MatrixRain from '@/components/MatrixRain';
export default function Home() {
  const [code, setCode] = useState('');
  const [output, setOutput] = useState('');
  const [language, setLanguage] = useState<'py' | 'cpp' | 'js'>('py');
  const [autoDetect, setAutoDetect] = useState(true);
  const [isRunning, setIsRunning] = useState(false);
  const [isSuccess, setIsSuccess] = useState(true);
  const [stats, setStats] = useState({ execCount: 0, successCount: 0, errorCount: 0 });

  useEffect(() => {
    const settings = getSettings();
    setAutoDetect(settings.autoDetect);

    // Restore last code
    const lastCode = getLastCode();
    if (lastCode) {
      setCode(lastCode.code);
      setLanguage(lastCode.language as 'py' | 'cpp' | 'js');
    }

    // Load stats from localStorage
    const savedStats = localStorage.getItem('omniterm-stats');
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }
  }, []);

  const languages = [
    { value: 'py' as const, name: 'Python', icon: '🐍', gradient: 'from-blue-500 via-cyan-500 to-teal-500' },
    { value: 'cpp' as const, name: 'C++', icon: '💻', gradient: 'from-purple-500 via-pink-500 to-red-500' },
    { value: 'js' as const, name: 'JavaScript', icon: '⚡', gradient: 'from-yellow-500 via-orange-500 to-red-500' },
  ];

  const examples: Record<string, string> = {
    py: `# Python Example - Matrix Calculator
import random

def matrix_effect():
    print("█" * 50)
    print("  OMNITERM MATRIX CALCULATOR")
    print("█" * 50)
    
    # Generate random matrix
    matrix = [[random.randint(0, 9) for _ in range(5)] for _ in range(3)]
    
    print("\\n[MATRIX DATA]")
    for i, row in enumerate(matrix):
        print(f"Row {i+1}: {row}")
    
    # Calculate sum
    total = sum(sum(row) for row in matrix)
    print(f"\\n[RESULT] Total Sum: {total}")
    print("█" * 50)

matrix_effect()`,
    
    cpp: `// C++ Example - System Monitor
#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    cout << string(50, '=') << endl;
    cout << "  OMNITERM SYSTEM MONITOR" << endl;
    cout << string(50, '=') << endl;
    
    // Simulate system stats
    cout << "\\n[CPU INFO]" << endl;
    cout << "Cores: 8" << endl;
    cout << "Usage: 45%" << endl;
    
    cout << "\\n[MEMORY INFO]" << endl;
    cout << "Total: 16 GB" << endl;
    cout << "Used: 8.5 GB" << endl;
    cout << "Free: 7.5 GB" << endl;
    
    cout << "\\n[STATUS] System running optimally" << endl;
    cout << string(50, '=') << endl;
    
    return 0;
}`,
    
    js: `// JavaScript Example - Crypto Dashboard
console.log("=".repeat(50));
console.log("  OMNITERM CRYPTO DASHBOARD");
console.log("=".repeat(50));

// Crypto data
const cryptos = [
    { name: "Bitcoin", symbol: "BTC", price: 45000 },
    { name: "Ethereum", symbol: "ETH", price: 3200 },
    { name: "Solana", symbol: "SOL", price: 120 }
];

console.log("\\n[LIVE PRICES]");
cryptos.forEach(crypto => {
    const change = (Math.random() * 10 - 5).toFixed(2);
    const arrow = change > 0 ? "↑" : "↓";
    console.log(\`\${crypto.symbol}: $\${crypto.price} \${arrow} \${Math.abs(change)}%\`);
});

console.log("\\n[STATUS] Market data updated");
console.log("=".repeat(50));`
  };

  const handleRunCode = async () => {
    if (!code.trim()) {
      alert('⚠️ Please write some code first!');
      return;
    }

    setIsRunning(true);
    setOutput('');

    const startTime = Date.now();

    try {
      const result = await runCode({
        code,
        language,
        autoDetect,
      });

      const executionTime = Date.now() - startTime;
      const fullOutput = result.stdout || result.stderr;
      
      setOutput(fullOutput);
      setIsSuccess(result.status === 'success');

      // Update stats
      const newStats = {
        execCount: stats.execCount + 1,
        successCount: result.status === 'success' ? stats.successCount + 1 : stats.successCount,
        errorCount: result.status === 'error' ? stats.errorCount + 1 : stats.errorCount,
      };
      setStats(newStats);
      localStorage.setItem('omniterm-stats', JSON.stringify(newStats));

      // Save to history
      saveToHistory({
        code,
        language: result.detectedLanguage || language,
        output: fullOutput,
        status: result.status,
        executionTime,
      });

      // Save last code
      saveLastCode(code, language);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      setOutput(`[CONNECTION ERROR]\n${errorMsg}\n\nMake sure the backend server is running on http://localhost:8000`);
      setIsSuccess(false);
    } finally {
      setIsRunning(false);
    }
  };

  const handleClearOutput = () => {
    setOutput('');
  };

  const loadExample = () => {
    setCode(examples[language]);
  };

  return (
    <div className="min-h-screen pb-12">
      <MatrixRain />
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        
        {/* Header Section */}
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-matrix-green neon-text glitch" data-text="OMNITERM">
            OMNITERM
          </h1>
          <p className="text-neon-cyan font-mono text-sm">
            {'>'} PROFESSIONAL CODE EXECUTION TERMINAL v2.0
          </p>
        </div>

        {/* Language Selector */}
        <div className="card-3d glass-hacker rounded-2xl p-8 border-2 border-matrix-green/30 shadow-2xl shadow-matrix-green/10">
          <div className="flex items-center gap-3 mb-6">
            <Code2 className="w-6 h-6 text-matrix-green" />
            <h2 className="text-xl font-bold text-matrix-green font-mono">
              {'>'} SELECT_LANGUAGE
            </h2>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {languages.map((lang) => (
              <button
                key={lang.value}
                onClick={() => setLanguage(lang.value)}
                className={`btn-hacker ripple p-6 rounded-xl font-bold text-lg transition-all flex flex-col items-center gap-3 ${
                  language === lang.value
                    ? 'bg-matrix-green/20 border-matrix-green shadow-lg shadow-matrix-green/50'
                    : 'border-neon-cyan/30 hover:border-matrix-green/50'
                }`}
              >
                <span className="text-5xl">{lang.icon}</span>
                <span className={language === lang.value ? 'text-matrix-green' : 'text-neon-cyan'}>
                  {lang.name}
                </span>
              </button>
            ))}
            
            <button
              onClick={() => {
                const newValue = !autoDetect;
                setAutoDetect(newValue);
                saveSettings({ autoDetect: newValue });
              }}
              className={`btn-hacker ripple p-6 rounded-xl font-bold text-lg transition-all flex flex-col items-center gap-3 ${
                autoDetect
                  ? 'bg-matrix-green/20 border-matrix-green shadow-lg shadow-matrix-green/50'
                  : 'border-neon-cyan/30 hover:border-matrix-green/50'
              }`}
            >
              <span className="text-5xl">🔍</span>
              <span className={autoDetect ? 'text-matrix-green' : 'text-neon-cyan'}>
                Auto Detect
              </span>
            </button>
          </div>
        </div>

        {/* Code Editor */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-matrix-green" />
              <h3 className="text-lg font-mono text-matrix-green">CODE_EDITOR</h3>
            </div>
            <button
              onClick={loadExample}
              className="btn-hacker px-6 py-2 rounded-lg font-mono text-sm font-semibold text-neon-cyan hover:text-matrix-green transition-all flex items-center gap-2"
            >
              <Zap className="w-4 h-4" />
              LOAD_EXAMPLE
            </button>
          </div>
          
          <CodeEditor
            code={code}
            language={language}
            onChange={setCode}
            onRun={handleRunCode}
            placeholder={`// Write your ${language.toUpperCase()} code here...\n// Press Ctrl+Enter to execute`}
          />

          {/* Run Button */}
          <button
            onClick={handleRunCode}
            disabled={isRunning || !code}
            className="w-full btn-hacker py-6 rounded-xl font-bold text-xl transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed bg-gradient-to-r from-matrix-green/20 to-neon-cyan/20 hover:from-matrix-green/30 hover:to-neon-cyan/30 border-2 border-matrix-green"
          >
            {isRunning ? (
              <>
                <div className="spinner-hacker"></div>
                <span className="text-yellow-400">EXECUTING...</span>
              </>
            ) : (
              <>
                <Play className="w-6 h-6 text-matrix-green" />
                <span className="text-matrix-green">RUN_CODE</span>
                <Zap className="w-6 h-6 text-matrix-green" />
              </>
            )}
          </button>
        </div>

        {/* Terminal Output */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-matrix-green" />
            <h3 className="text-lg font-mono text-matrix-green">OUTPUT_TERMINAL</h3>
          </div>
          
          <TerminalWindow
            output={output}
            isRunning={isRunning}
            isSuccess={isSuccess}
            onClear={handleClearOutput}
          />
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="card-3d glass-hacker rounded-xl p-6 text-center border border-matrix-green/30">
            <div className="text-5xl mb-3">⚡</div>
            <div className="text-4xl font-bold text-matrix-green font-mono mb-2">
              {stats.execCount}
            </div>
            <div className="text-neon-cyan font-mono text-sm">TOTAL_EXECUTIONS</div>
          </div>
          
          <div className="card-3d glass-hacker rounded-xl p-6 text-center border border-matrix-green/30">
            <div className="text-5xl mb-3">✅</div>
            <div className="text-4xl font-bold text-matrix-green font-mono mb-2">
              {stats.successCount}
            </div>
            <div className="text-neon-cyan font-mono text-sm">SUCCESS</div>
          </div>
          
          <div className="card-3d glass-hacker rounded-xl p-6 text-center border border-matrix-green/30">
            <div className="text-5xl mb-3">❌</div>
            <div className="text-4xl font-bold text-red-500 font-mono mb-2">
              {stats.errorCount}
            </div>
            <div className="text-neon-cyan font-mono text-sm">ERRORS</div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-16 py-8 text-center border-t border-matrix-green/20">
        <p className="text-neon-cyan/70 font-mono text-sm">
          {'>'} OMNITERM_v2.0 | Made with ❤️ by OmniTerm Team | Press Ctrl+Enter to execute
        </p>
      </footer>
    </div>
  );
}
