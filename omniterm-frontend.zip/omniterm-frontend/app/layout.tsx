import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'OmniTerm - Professional Code Terminal',
  description: 'Execute Python, C++, and JavaScript code in a beautiful terminal',
  keywords: ['code editor', 'terminal', 'python', 'c++', 'javascript', 'compiler'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>💻</text></svg>" />
      </head>
      <body className="antialiased">
        {/* Matrix Rain Background */}
        <div className="matrix-bg" id="matrix-bg"></div>
        
        {/* Grid Background */}
        <div className="fixed inset-0 grid-bg pointer-events-none" style={{ zIndex: 0 }}></div>
        
        {/* Main Content */}
        <div className="relative z-10">
          {children}
        </div>
      </body>
    </html>
  );
}
