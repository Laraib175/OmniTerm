// Create this file at: frontend/src/services/api.js

const API_BASE_URL = 'http://localhost:8000';

export const codeAPI = {
  // Test backend connection
  async ping() {
    try {
      const response = await fetch(`${API_BASE_URL}/api/ping`);
      return await response.json();
    } catch (error) {
      console.error('Backend connection failed:', error);
      throw new Error('Cannot connect to backend. Make sure it is running on port 8000.');
    }
  },

  // Execute code
  async runCode(code, language = 'py', autoDetect = false) {
    try {
      const response = await fetch(`${API_BASE_URL}/api/run`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code,
          language,
          autoDetect
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Code execution failed:', error);
      throw error;
    }
  }
};

export default codeAPI;
