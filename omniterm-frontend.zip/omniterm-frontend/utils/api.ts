// API utility functions for OmniTerm backend communication

export interface RunCodeRequest {
  code: string;
  language: 'py' | 'cpp' | 'js';
  autoDetect?: boolean;
}

export interface RunCodeResponse {
  stdout: string;
  stderr: string;
  returncode: number;
  status: 'success' | 'error';
  detectedLanguage?: string;
}

export interface HistoryItem {
  id: string;
  code: string;
  language: string;
  output: string;
  timestamp: string;
  status: 'success' | 'error';
  executionTime?: number;
}

export interface Settings {
  darkMode: boolean;
  autoDetect: boolean;
  fontSize: number;
  theme: string;
  notifications: boolean;
  autoSave: boolean;
  soundEffects: boolean;
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

// Run code on the backend
export async function runCode(request: RunCodeRequest): Promise<RunCodeResponse> {
  try {
    const startTime = Date.now();
    
    const response = await fetch(`${API_BASE_URL}/api/run`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    const executionTime = Date.now() - startTime;

    return {
      stdout: data.stdout || '',
      stderr: data.stderr || '',
      returncode: data.returncode || 0,
      status: data.returncode === 0 ? 'success' : 'error',
      detectedLanguage: data.detectedLanguage,
    };
  } catch (error) {
    console.error('API Error:', error);
    return {
      stdout: '',
      stderr: error instanceof Error ? error.message : 'Unknown error occurred',
      returncode: -1,
      status: 'error',
    };
  }
}

// Check API health
export async function pingAPI(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE_URL}/api/ping`);
    return response.ok;
  } catch {
    return false;
  }
}

// LocalStorage Helper Functions
const STORAGE_KEYS = {
  HISTORY: 'omniterm-history',
  SETTINGS: 'omniterm-settings',
  LAST_CODE: 'omniterm-last-code',
};

// Get execution history
export function getHistory(): HistoryItem[] {
  if (typeof window === 'undefined') return [];
  
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

// Save execution to history
export function saveToHistory(item: Omit<HistoryItem, 'id' | 'timestamp'>): void {
  if (typeof window === 'undefined') return;
  
  try {
    const history = getHistory();
    const newItem: HistoryItem = {
      ...item,
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
    };
    
    const updatedHistory = [newItem, ...history].slice(0, 100); // Keep last 100 items
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updatedHistory));
  } catch (error) {
    console.error('Error saving to history:', error);
  }
}

// Clear all history
export function clearHistory(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEYS.HISTORY);
}

// Get settings
export function getSettings(): Settings {
  if (typeof window === 'undefined') {
    return getDefaultSettings();
  }
  
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return stored ? { ...getDefaultSettings(), ...JSON.parse(stored) } : getDefaultSettings();
  } catch {
    return getDefaultSettings();
  }
}

// Save settings
export function saveSettings(settings: Partial<Settings>): void {
  if (typeof window === 'undefined') return;
  
  try {
    const currentSettings = getSettings();
    const updatedSettings = { ...currentSettings, ...settings };
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updatedSettings));
  } catch (error) {
    console.error('Error saving settings:', error);
  }
}

// Get default settings
function getDefaultSettings(): Settings {
  return {
    darkMode: true,
    autoDetect: true,
    fontSize: 14,
    theme: 'hacker',
    notifications: true,
    autoSave: false,
    soundEffects: false,
  };
}

// Save last code
export function saveLastCode(code: string, language: string): void {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(STORAGE_KEYS.LAST_CODE, JSON.stringify({ code, language, timestamp: Date.now() }));
  } catch (error) {
    console.error('Error saving last code:', error);
  }
}

// Get last code
export function getLastCode(): { code: string; language: string } | null {
  if (typeof window === 'undefined') return null;
  
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.LAST_CODE);
    if (!stored) return null;
    
    const data = JSON.parse(stored);
    const hoursSinceLastSave = (Date.now() - data.timestamp) / (1000 * 60 * 60);
    
    // Only return if less than 24 hours old
    return hoursSinceLastSave < 24 ? { code: data.code, language: data.language } : null;
  } catch {
    return null;
  }
}

// Export history as JSON
export function exportHistory(): void {
  if (typeof window === 'undefined') return;
  
  const history = getHistory();
  const dataStr = JSON.stringify(history, null, 2);
  const dataBlob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(dataBlob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = `omniterm-history-${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Format timestamp
export function formatTimestamp(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
  
  return date.toLocaleDateString();
}

// Get language emoji
export function getLanguageEmoji(language: string): string {
  const emojis: Record<string, string> = {
    py: '🐍',
    python: '🐍',
    cpp: '💻',
    'c++': '💻',
    js: '⚡',
    javascript: '⚡',
  };
  return emojis[language.toLowerCase()] || '📝';
}

// Get language color
export function getLanguageColor(language: string): string {
  const colors: Record<string, string> = {
    py: 'from-blue-500 to-cyan-500',
    python: 'from-blue-500 to-cyan-500',
    cpp: 'from-purple-500 to-pink-500',
    'c++': 'from-purple-500 to-pink-500',
    js: 'from-yellow-500 to-orange-500',
    javascript: 'from-yellow-500 to-orange-500',
  };
  return colors[language.toLowerCase()] || 'from-gray-500 to-gray-700';
}
