'use client';

import React, { useRef, useEffect } from 'react';
import { Copy, Trash2, CheckCircle, XCircle, Download, Terminal } from 'lucide-react';

interface TerminalWindowProps {
  output: string;
  isRunning?: boolean;
  isSuccess?: boolean;
  onClear?: () => void;
}

export default function TerminalWindow({
  output,
  isRunning = false,
  isSuccess = true,
  onClear,
}: TerminalWindowProps) {
  const outputRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [output]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output);
    // Could add toast notification here
  };

  const downloadOutput = () => {
    const blob = new Blob([output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `output-${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const getStatusColor = () => {
    if (isRunning) return 'bg-yellow-500';
    if (isSuccess) return 'bg-matrix-green';
    return 'bg-red-500';
  };

  const getStatusText = () => {
    if (isRunning) return 'EXECUTING';
    if (isSuccess) return 'SUCCESS';
    return 'ERROR';
  };

  return (
    <div className="card-3d glass-hacker rounded-2xl overflow-hidden border-2 border-matrix-green/30 shadow-2xl shadow-matrix-green/10">
      {/* Terminal Header */}
      <div className="flex items-center justify-between px-6 py-3 bg-black/70 border-b border-matrix-green/30">
        <div className="flex items-center gap-3">
          {/* Traffic Lights */}
          <div className="flex gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500 shadow-lg shadow-red-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500 shadow-lg shadow-yellow-500/50"></div>
            <div className="w-3 h-3 rounded-full bg-green-500 shadow-lg shadow-green-500/50"></div>
          </div>
          
          <Terminal className="w-5 h-5 text-matrix-green ml-2" />
          <span className="text-matrix-green font-mono font-semibold">OUTPUT TERMINAL</span>
        </div>

        <div className="flex items-center gap-3">
          {/* Status Indicator */}
          <div className="flex items-center gap-2 px-3 py-1 bg-black/50 rounded-lg border border-matrix-green/30">
            <div className={`w-2 h-2 rounded-full ${getStatusColor()} animate-pulse`}></div>
            <span className="text-xs text-matrix-green font-mono">{getStatusText()}</span>
          </div>

          {/* Action Buttons */}
          <button
            onClick={copyToClipboard}
            disabled={!output || isRunning}
            className="p-2 text-neon-cyan hover:text-matrix-green hover:bg-matrix-green/10 rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed tooltip"
            data-tooltip="Copy Output"
          >
            <Copy className="w-4 h-4" />
          </button>
          <button
            onClick={downloadOutput}
            disabled={!output || isRunning}
            className="p-2 text-neon-cyan hover:text-matrix-green hover:bg-matrix-green/10 rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed tooltip"
            data-tooltip="Download"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={onClear}
            disabled={!output || isRunning}
            className="p-2 text-red-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed tooltip"
            data-tooltip="Clear Terminal"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Terminal Body */}
      <div className="bg-black relative">
        <div
          ref={outputRef}
          className="h-[400px] overflow-y-auto p-6 font-mono text-sm scanlines"
        >
          {isRunning ? (
            <div className="flex flex-col items-center justify-center h-full">
              <div className="spinner-hacker mb-4"></div>
              <p className="text-yellow-400 font-mono animate-pulse">
                {'>'} Executing code...
              </p>
              <div className="flex gap-1 mt-2">
                <span className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></span>
                <span className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                <span className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
              </div>
            </div>
          ) : output ? (
            <div>
              <div className="flex items-center gap-2 mb-3 pb-2 border-b border-matrix-green/20">
                {isSuccess ? (
                  <CheckCircle className="w-5 h-5 text-matrix-green" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
                <span className={`font-mono font-semibold ${isSuccess ? 'text-matrix-green' : 'text-red-500'}`}>
                  {isSuccess ? '[SUCCESS]' : '[ERROR]'}
                </span>
                <span className="text-neon-cyan/50 text-xs">
                  {new Date().toLocaleTimeString()}
                </span>
              </div>
              <pre className={`whitespace-pre-wrap break-words ${isSuccess ? 'text-matrix-green' : 'text-red-400'}`}>
                {output}
              </pre>
              <div className="mt-4 flex items-center gap-2 text-neon-cyan/50">
                <span className="text-xs font-mono">$</span>
                <div className="terminal-cursor"></div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <Terminal className="w-16 h-16 text-matrix-green/30 mb-4" />
              <p className="text-neon-cyan/50 font-mono text-sm mb-2">
                {'>'} Terminal ready
              </p>
              <p className="text-neon-cyan/30 font-mono text-xs">
                Output will appear here when you run code
              </p>
              <div className="mt-6 flex items-center gap-2 text-neon-cyan/30">
                <span className="text-xs font-mono">$</span>
                <div className="terminal-cursor"></div>
              </div>
            </div>
          )}
        </div>

        {/* Scanline effect overlay */}
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-matrix-green/5 to-transparent"></div>
      </div>

      {/* Terminal Footer */}
      <div className="px-6 py-3 bg-black/70 border-t border-matrix-green/30 flex items-center justify-between">
        <div className="flex items-center gap-4 text-xs text-neon-cyan/70 font-mono">
          <span>omniterm@localhost:~$</span>
          <span>•</span>
          <span>Ready for input</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-neon-cyan/70 font-mono">
          <span>Encoding: UTF-8</span>
        </div>
      </div>
    </div>
  );
}
