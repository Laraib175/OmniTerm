'use client';

import React, { useState, KeyboardEvent } from 'react';
import { Send, Loader2 } from 'lucide-react';

interface CommandInputProps {
  onSubmit: (command: string) => void;
  isLoading?: boolean;
  darkMode?: boolean;
  placeholder?: string;
}

export default function CommandInput({
  onSubmit,
  isLoading = false,
  darkMode = true,
  placeholder = 'Type your command...',
}: CommandInputProps) {
  const [command, setCommand] = useState('');

  const handleSubmit = () => {
    if (command.trim() && !isLoading) {
      onSubmit(command);
      setCommand('');
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  return (
    <div className="flex items-center gap-3">
      <input
        type="text"
        value={command}
        onChange={(e) => setCommand(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder={placeholder}
        disabled={isLoading}
        className={`flex-1 px-4 py-3 rounded-xl font-mono text-sm ${
          darkMode
            ? 'bg-gray-900 text-green-400 placeholder-gray-600 border-purple-500/30'
            : 'bg-gray-50 text-gray-900 placeholder-gray-400 border-purple-300'
        } border-2 focus:outline-none focus:ring-2 focus:ring-purple-500 disabled:opacity-50`}
      />
      <button
        onClick={handleSubmit}
        disabled={!command.trim() || isLoading}
        className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-xl font-semibold transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
      >
        {isLoading ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <Send className="w-5 h-5" />
        )}
      </button>
    </div>
  );
}
