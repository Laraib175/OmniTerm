'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Terminal, History, Settings, Zap, Activity } from 'lucide-react';

interface NavbarProps {
  darkMode?: boolean;
  onToggleDarkMode?: () => void;
}

export default function Navbar({ darkMode = true, onToggleDarkMode }: NavbarProps) {
  const pathname = usePathname();

  const navItems = [
    { href: '/', label: 'Terminal', icon: Terminal },
    { href: '/history', label: 'History', icon: History },
    { href: '/settings', label: 'Settings', icon: Settings },
  ];

  return (
    <nav className="glass-hacker sticky top-0 z-50 border-b border-matrix-green/20 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo Section */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-matrix-green rounded-lg blur-lg opacity-50 animate-pulse-glow"></div>
              {/* Icon */}
              <div className="relative bg-gradient-to-br from-matrix-green to-neon-cyan p-2 rounded-lg transform group-hover:scale-110 transition-transform">
                <Terminal className="w-6 h-6 text-darker-bg" />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-matrix-green glitch font-mono" data-text="OmniTerm">
                OmniTerm
              </h1>
              <p className="text-xs text-neon-cyan font-mono">v2.0.0_HACKER</p>
            </div>
          </Link>

          {/* Navigation Items */}
          <div className="flex items-center gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;
              
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium font-mono transition-all transform hover:scale-105 ${
                    isActive
                      ? 'bg-matrix-green/20 text-matrix-green border border-matrix-green shadow-lg shadow-matrix-green/50'
                      : 'text-neon-cyan hover:bg-matrix-green/10 hover:text-matrix-green border border-transparent hover:border-matrix-green/30'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{item.label}</span>
                </Link>
              );
            })}

            {/* Status Indicator */}
            <div className="ml-4 flex items-center gap-2 px-3 py-2 rounded-lg bg-black/50 border border-matrix-green/30 shadow-inner">
              <div className="relative">
                <div className="status-online"></div>
              </div>
              <span className="text-xs text-matrix-green font-mono font-semibold">ONLINE</span>
            </div>

            {/* Activity Pulse */}
            <div className="relative ml-2 p-2">
              <Activity className="w-5 h-5 text-matrix-green animate-pulse" />
              <span className="absolute top-0 right-0 w-2 h-2 bg-matrix-green rounded-full animate-ping"></span>
            </div>
          </div>
        </div>
      </div>

      {/* Animated bottom border */}
      <div className="h-0.5 bg-gradient-to-r from-transparent via-matrix-green to-transparent"></div>
    </nav>
  );
}