'use client';

import React, { useRef, useEffect } from 'react';
import { Code2, Download, Upload, Copy, Maximize2 } from 'lucide-react';

interface CodeEditorProps {
  code: string;
  language: string;
  onChange: (code: string) => void;
  onRun?: () => void;
  placeholder?: string;
}

export default function CodeEditor({
  code,
  language,
  onChange,
  onRun,
  placeholder = '// Start coding...'
}: CodeEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [code]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Ctrl/Cmd + Enter to run
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      onRun?.();
    }

    // Tab support
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = e.currentTarget.selectionStart;
      const end = e.currentTarget.selectionEnd;
      const newValue = code.substring(0, start) + '    ' + code.substring(end);
      onChange(newValue);
      
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 4;
        }
      }, 0);
    }
  };

  const downloadCode = () => {
    const extensions: Record<string, string> = {
      py: 'py',
      cpp: 'cpp',
      js: 'js',
    };
    const ext = extensions[language] || 'txt';
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `code.${ext}`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
  };

  return (
    <div className="card-3d glass-hacker rounded-2xl overflow-hidden border-2 border-matrix-green/30 shadow-2xl shadow-matrix-green/10">
      {/* Editor Header */}
      <div className="flex items-center justify-between px-6 py-3 bg-black/50 border-b border-matrix-green/30">
        <div className="flex items-center gap-3">
          <Code2 className="w-5 h-5 text-matrix-green" />
          <span className="text-matrix-green font-mono font-semibold">CODE EDITOR</span>
          <span className="px-2 py-1 bg-matrix-green/20 text-matrix-green text-xs font-mono rounded border border-matrix-green/50">
            {language.toUpperCase()}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={copyCode}
            disabled={!code}
            className="p-2 text-neon-cyan hover:text-matrix-green hover:bg-matrix-green/10 rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed tooltip"
            data-tooltip="Copy Code"
          >
            <Copy className="w-4 h-4" />
          </button>
          <button
            onClick={downloadCode}
            disabled={!code}
            className="p-2 text-neon-cyan hover:text-matrix-green hover:bg-matrix-green/10 rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed tooltip"
            data-tooltip="Download"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            className="p-2 text-neon-cyan hover:text-matrix-green hover:bg-matrix-green/10 rounded-lg transition-all tooltip"
            data-tooltip="Fullscreen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Line Numbers & Editor */}
      <div className="flex bg-gradient-to-br from-darker-bg to-dark-bg">
        {/* Line Numbers */}
        <div className="px-4 py-6 bg-black/30 border-r border-matrix-green/20 select-none">
          {code.split('\n').map((_, i) => (
            <div
              key={i}
              className="text-right text-neon-cyan/50 font-mono text-sm leading-6"
            >
              {i + 1}
            </div>
          ))}
        </div>

        {/* Code Textarea */}
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={code}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            spellCheck={false}
            className="w-full min-h-[500px] px-6 py-6 bg-transparent text-matrix-green font-mono text-sm leading-6 resize-none focus:outline-none placeholder-neon-cyan/30 scanlines"
            style={{
              tabSize: 4,
              MozTabSize: 4,
            }}
          />
          
          {/* Cursor indicator */}
          <div className="absolute bottom-4 right-4 flex items-center gap-2 px-3 py-1 bg-black/70 rounded-lg border border-matrix-green/30">
            <span className="text-xs text-neon-cyan font-mono">
              {code.split('\n').length} lines
            </span>
            <span className="text-matrix-green">•</span>
            <span className="text-xs text-neon-cyan font-mono">
              {code.length} chars
            </span>
          </div>
        </div>
      </div>

      {/* Editor Footer */}
      <div className="px-6 py-3 bg-black/50 border-t border-matrix-green/30 flex items-center justify-between">
        <div className="flex items-center gap-4 text-xs text-neon-cyan/70 font-mono">
          <span>UTF-8</span>
          <span>•</span>
          <span>Spaces: 4</span>
          <span>•</span>
          <span className="text-matrix-green">Ctrl+Enter to run</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-matrix-green animate-pulse"></div>
          <span className="text-xs text-matrix-green font-mono">READY</span>
        </div>
      </div>
    </div>
  );
}
